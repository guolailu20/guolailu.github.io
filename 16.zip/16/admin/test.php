<?php
 phpinfo();