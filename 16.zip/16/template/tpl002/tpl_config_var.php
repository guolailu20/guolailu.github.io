<?php exit();?>
video_page_size === hide === 列表显示内容的数量 === 20
bt_page_size === hide === 列表显示内容的数量 === 20
logo_text === textarea === logo图标 === <span class="text-zinc-50">Seyou</span><span class="text-primary">CMS</span>
site_statement === textarea === 网站声明 === 免责声明：若本站收录的资源侵犯了您的权益，请发邮件至：123456@qq.com，我们会及时删除侵权内容，谢谢合作，本站每日更新，开始播放后不会再有广告，支援任何装置包括手机，电脑及智能电视。免费加入会员后可任意收藏影片供日后观赏。

link_fix_url === text === 底部链接>地址发布 === https://t.me/sycms
link_contact === text === 底部链接>联系我们 === https://t.me/sycms
link_adv === text === 底部链接>投放广告 === https://t.me/sycms
link_backup_url === text === 底部链接>备用地址 === https://t.me/sycms