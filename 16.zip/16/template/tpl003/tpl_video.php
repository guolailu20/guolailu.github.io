﻿<?php exit();?><!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <title>{@page_title}</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link href="/template/{@var:cms_config_tpl_dir}/css/all-responsive-metal.css?5" rel="stylesheet" type="text/css" />
        <link href="/template/{@var:cms_config_tpl_dir}/css/jquery.fancybox-metal.css" rel="stylesheet" type="text/css" />
        <script src="/template/{@var:cms_config_tpl_dir}/js/common.js?5"></script>
        {@common_head}
    </head>
    
    <body>
        <div class="container">

            {@include file:header}

            <div class="content">
                <div class="main-content">
                    <div class="main-container">
                        <div class="headline">
                            <h1>{@name}</h1></div>
                        <div class="block-video">
                            <div class="video-holder">
                                <div class="player">
                                    <div class="player-holder">
                                        <div id="player" style="width:100%;height:100%;">
                                            <script src="https://cdn.jsdelivr.net/hls.js/latest/hls.min.js"></script>
                                            <video class="player-box" src="{@m3u8}" id="video" style="width:100%;height:100%;max-height: 720px;" controls autoplay></video>
                                            <script>
                                                if (Hls.isSupported()) {
                                                    var video = document.getElementById('video'); // 获取 video 标签
                                                    var hls = new Hls(); // 实例化 Hls 对象
                                                    hls.loadSource('{@m3u8}'); // 传入路径
                                                    hls.attachMedia(video);
                                                    hls.on(Hls.Events.MANIFEST_PARSED, function () {
                                                        video.play(); // 调用播放 API
                                                    });
                                                }
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="related-videos" id="list_videos_related_videos">
                            <ul class="list-sort" id="list_videos_related_videos_filter_list">
                                <li>
                                    <span>相关视频</span></li>
                            </ul>
                            <div class="box">
                                <div class="list-videos">
                                    <div class="margin-fix" id="list_videos_related_videos_items">
                                    {list type:video mode:rand total:8 title_len:24}
                                        <div class="item">
                                            <a href="{_url}">
                                                <div class="img">
                                                    <img class="thumb lazy-load" referrerpolicy="no-referrer" src="{_pic}" /></div>
                                                <strong class="title">{_title}</strong>
                                            </a>
                                        </div>
                                    {/list}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {@include file:footer}
        </div>
    </body>
</html>