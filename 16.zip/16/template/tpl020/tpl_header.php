    <div id="app">
        <div class="page">
            <div class="top">

{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;margin: 1px 0px;" class="{_class}"></a>
</div>
{/ad}

                
                <div class="search van-row van-row--flex van-row--align-center van-row--justify-space-between">
                    <a href="/" style="margin-left: 20px;">
                        <img  class="logo" src="/template/{@var:cms_config_tpl_dir}/picture/logo.png" >
                    </a>
                    <div class="seek van-row van-row--flex van-row--align-center" style="width: 55%; margin-right: 20px;">
                        <i class="van-col"></i>

                        <input style="flex: 0.959 1 0%;" type="text" id="content" name="content" placeholder="&#24819;&#30475;&#20160;&#20040;&#25628;&#20160;&#20040;" class="van-ellipsis van-col">
                        <div style="font-size: 0.4rem;color: #fff;background-color: #ff9903;height: .96rem;line-height: .96rem;width: 1.1rem;text-align: center;border-radius: 0 .2rem .2rem 0;margin-right: -.33rem;cursor: pointer;" id="search_sub">
                            搜索
                        </div>
                        <script>
                            document.getElementById("search_sub").addEventListener("click", function() {
                                var sword = document.getElementById("content").value;
                                if (sword !== "") {
                                    window.location.href = "/search.php?content=" + sword + "";
                                } else {
                                    alert("请输入搜索内容");
                                }
                            });
                            document.getElementById("content").addEventListener('keypress', function(event) {
                                if (event.keyCode === 13) {
                                    var sword = document.getElementById("content").value;
                                    if (sword !== "") {
                                        window.location.href = "/search.php?content=" + sword + "";
                                    } else {
                                        alert("请输入搜索内容");
                                    }
                                }
                            });
                        </script>
                    </div>
                </div>
                <div class="nav van-row van-row--flex van-row--align-center">
                    <div class="nav1">
                        <div class="nav_box van-row van-row--flex van-row--align-center van-row--justify-center">

                            <a href="/13mei/?index=index" class="van-col van-col--6 nav_item index" style="display: none;">网站首页</a>

{nav type:video no:v2 count:8} 
<a href='{_class_link}' class='nav_item '>{_class_name}</a>
{/nav}
{nav type:bt no:1 count:2 name:国产磁力,日本磁力} 
<a href='{_class_link}' class='nav_item '>{_class_name}</a>
{/nav}




                        </div>
                    </div>
                </div>
                <style>
                    .nav {
                        padding: .321333rem .1666rem .21333rem .1666rem;
                    }

                    .nav1 {
                        width: 100%;
                        float: none;
                        margin: 0;
                    }

                    .nav .nav_box {
                        width: 100%;
                        border-radius: .48rem;
                        background: #ff9903;
                        overflow: hidden;
                    }

                    .nav .nav_box .nav_item {
                        font-family: PingFangSC-Regular;
                        font-size: .37333rem;
                        color: #fff;
                        text-align: center;
                        height: 1rem;
                        line-height: 1rem;
                        width: calc(100%/5);
                    }

                    .nav .nav_box .nav_item:hover {
                        background: #242424;
                    }
                </style>
            </div>
            <style>
                .play_nav.van-grid {
                    padding: .26667rem 0 0 0;
                    width: 98%;
                    margin: 0 auto;
                }

                .rec_link_box a:nth-of-type(1),
                .el-links .link_box a:nth-of-type(1) {
                    background: #b70e1e;
                }

                .rec_link_box a:nth-of-type(2),
                .el-links .link_box a:nth-of-type(2) {
                    background: #f95b8e;
                }

                .rec_link_box a:nth-of-type(3),
                .el-links .link_box a:nth-of-type(3) {
                    background: #bc00bf;
                }

                .rec_link_box a:nth-of-type(4),
                .el-links .link_box a:nth-of-type(4) {
                    background: #3228c7;
                }

                .rec_link_box a:nth-of-type(5),
                .el-links .link_box a:nth-of-type(5) {
                    background: #e78b00;
                }

                .rec_link_box a:nth-of-type(6),
                .el-links .link_box a:nth-of-type(6) {
                    background: #31934a;
                }

                .rec_link_box a:nth-of-type(7),
                .el-links .link_box a:nth-of-type(7) {
                    background: #c95720;
                }

                .rec_link_box a:nth-of-type(8),
                .el-links .link_box a:nth-of-type(8) {
                    background: #0b9299;
                }

                .rec_link_box a:nth-of-type(9),
                .el-links .link_box a:nth-of-type(9) {
                    background: #FF6347;
                }

                .rec_link_box a:nth-of-type(10),
                .el-links .link_box a:nth-of-type(10) {
                    background: #ed4000;
                }

                .rec_link_box a:nth-of-type(11) {
                    background: #0bc3a1;
                }

                .rec_link_box a:nth-of-type(12) {
                    background: #8A2BE2;
                }

                .rec_link_box a:nth-of-type(13) {
                    background: #1a7cdb;
                }

                .rec_link_box a:nth-of-type(14) {
                    background: #20B2AA;
                }

                .rec_link_box a:nth-of-type(15) {
                    background: #36a936;
                }

                .rec_link_box a:nth-of-type(16) {
                    background: #90BE6D;
                }

                .rec_link_box a:nth-of-type(17) {
                    background: #db3b00;
                }

                .rec_link_box a:nth-of-type(18) {
                    background: #abbf3a;
                }

                .rec_link_box a:nth-of-type(19) {
                    background: #9b4ee2;
                }

                .rec_link_box a:nth-of-type(20) {
                    background: #3f85c9;
                }

                .rec_link_box a:nth-of-type(21),
                .el-links .link_box a:nth-of-type(11) {
                    color: #ff283c;
                }

                .rec_link_box a:nth-of-type(22),
                .el-links .link_box a:nth-of-type(12) {
                    color: #f95b8e;
                }

                .rec_link_box a:nth-of-type(23),
                .el-links .link_box a:nth-of-type(13) {
                    color: #e900ed;
                }

                .rec_link_box a:nth-of-type(24),
                .el-links .link_box a:nth-of-type(14) {
                    color: #5d8fed;
                }

                .rec_link_box a:nth-of-type(25),
                .el-links .link_box a:nth-of-type(15) {
                    color: #e78b00;
                }

                .rec_link_box a:nth-of-type(26),
                .el-links .link_box a:nth-of-type(16) {
                    color: #31934a;
                }

                .rec_link_box a:nth-of-type(27),
                .el-links .link_box a:nth-of-type(17) {
                    color: #c95720;
                }

                .rec_link_box a:nth-of-type(28),
                .el-links .link_box a:nth-of-type(18) {
                    color: #0b9299;
                }

                .rec_link_box a:nth-of-type(29),
                .el-links .link_box a:nth-of-type(19) {
                    color: #0bc3a1;
                }

                .rec_link_box a:nth-of-type(30),
                .el-links .link_box a:nth-of-type(20) {
                    color: #FF6347;
                }

                .rec_link_box a:nth-of-type(n+21):nth-of-type(-n+30) {
                    font-weight: bold;
                }

                .el-links .link_box,
                .rec_link_box {
                    display: grid;
                    grid-template-columns: repeat(5, 1fr);
                    padding: .26667rem .02667rem .31rem .16667rem;
                }

                .el-links .link_box a,
                .rec_link_box a {
                    background-color: #ffffff17;
                    color: #ededed;
                    height: .666666rem;
                    line-height: .666666rem;
                    text-align: center;
                    border-radius: .10667rem;
                    font-size: .343rem;
                    margin: 0 0.1rem 0.1rem 0;
                }

                .el-links a:hover,
                .rec_link_box a:hover {
                    background: #484848;
                    color: #fff;
                }
            </style>
<!--             <div class="play_nav van-grid"><a href="https:/资料/"  class="van-grid-item">
                    <div class="van-grid-item__content van-grid-item__content--center">
                        <div class="van-grid-item__icon-wrapper">
                            <div class="play_nav_icon van-image"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="/template/{@var:cms_config_tpl_dir}/13mei/static/linkico/mmyjs.webp" style="object-fit: cover;border-radius: 6px;"></div>
                        </div><span class="play_nav_text van-ellipsis">&#31192;&#23494;&#30740;&#31350;&#25152;</span>
                    </div>
                </a><a href="ht%98%8E"  class="van-grid-item">
                    <div class="van-grid-item__content van-grid-item__content--center">
                        <div class="van-grid-item__icon-wrapper">
                            <div class="play_nav_icon van-image"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="/template/{@var:cms_config_tpl_dir}/13mei/static/linkico/buliang.webp" style="object-fit: cover;border-radius: 6px;"></div>
                        </div><span class="play_nav_text van-ellipsis">&#19981;&#33391;&#30740;&#31350;&#25152;</span>
                    </div>
                </a>
            </div> -->

            <div class="rec_link_box">
{link area:link_dblj}
                <a  rel='nofollow' href="{_url}" target="_blank">{base64}{_text}{/base64}</a>
{/link}


            </div>

<!--             <div class="notice_bars" style="border: 1px solid #ffffff1c;">
                <div class="van-notice-bar">
                    <div class="left_icon">
                        <div><span style="background: #ff9903;margin-left: .1rem;padding: .05rem .1rem;border-radius: 5px;color: #000000;font-weight: bold;">📢</span></div>
                    </div>
                    <div style="cursor: pointer;color: #dbd7d2;">最新网址：</div>
                </div>
            </div>
 -->