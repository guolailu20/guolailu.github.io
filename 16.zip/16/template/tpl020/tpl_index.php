<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <title>{@page_title}</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
    <link rel="icon" href="/favicon.ico">
    <link href='/template/{@var:cms_config_tpl_dir}/css/app.css' rel='stylesheet'>
<link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body>
{@include file:header}


            <div class="van-pull-refresh">
                <div class="van-pull-refresh__track">
                    <div class="theme_list">





                        <div class="list">
                            <div class="van-row">
                                <div class="van-cell van-cell--clickable">
                                    <div class="van-cell__title">
                                        <span>{@class_name type:video index:1}</span>
                                    </div>
                                    <a href="{@class_link type:video index:1}" class="van-cell__value">
                                        <span>更多&nbsp;&gt;&nbsp;&nbsp;</span><i class="van-icon van-icon-arrow van-cell__right-icon"></i>
                                    </a>
                                </div>
{list type:video index:1 total:8 title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
{/list}
                            </div>
                        </div>


                        <div class="list">
                            <div class="van-row">
                                <div class="van-cell van-cell--clickable">
                                    <div class="van-cell__title">
                                        <span>{@class_name type:video index:4}</span>
                                    </div>
                                    <a href="{@class_link type:video index:4}" class="van-cell__value">
                                        <span>更多&nbsp;&gt;&nbsp;&nbsp;</span><i class="van-icon van-icon-arrow van-cell__right-icon"></i>
                                    </a>
                                </div>
{list type:video index:4 total:8 title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
{/list}
                            </div>
                        </div>


                        <div class="list">
                            <div class="van-row">
                                <div class="van-cell van-cell--clickable">
                                    <div class="van-cell__title">
                                        <span>{@class_name type:video index:3}</span>
                                    </div>
                                    <a href="{@class_link type:video index:3}" class="van-cell__value">
                                        <span>更多&nbsp;&gt;&nbsp;&nbsp;</span><i class="van-icon van-icon-arrow van-cell__right-icon"></i>
                                    </a>
                                </div>
{list type:video index:3 total:8 title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
{/list}
                            </div>
                        </div>


                        <div class="list">
                            <div class="van-row">
                                <div class="van-cell van-cell--clickable">
                                    <div class="van-cell__title">
                                        <span>{@class_name type:video index:2}</span>
                                    </div>
                                    <a href="{@class_link type:video index:2}" class="van-cell__value">
                                        <span>更多&nbsp;&gt;&nbsp;&nbsp;</span><i class="van-icon van-icon-arrow van-cell__right-icon"></i>
                                    </a>
                                </div>
{list type:video index:2 total:8 title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
{/list}
                            </div>
                        </div>


                        <div class="list">
                            <div class="van-row">
                                <div class="van-cell van-cell--clickable">
                                    <div class="van-cell__title">
                                        <span>{base64}国产磁力{/base64}</span>
                                    </div>
                                    <a href="{@class_link type:bt index:1}" class="van-cell__value">
                                        <span>更多&nbsp;&gt;&nbsp;&nbsp;</span><i class="van-icon van-icon-arrow van-cell__right-icon"></i>
                                    </a>
                                </div>
{list type:bt index:1 total:8 title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
{/list}
                            </div>
                        </div>




                        <div class="list">
                            <div class="van-row">
                                <div class="van-cell van-cell--clickable">
                                    <div class="van-cell__title">
                                        <span>{base64}日本磁力{/base64}</span>
                                    </div>
                                    <a href="{@class_link type:bt index:2}" class="van-cell__value">
                                        <span>更多&nbsp;&gt;&nbsp;&nbsp;</span><i class="van-icon van-icon-arrow van-cell__right-icon"></i>
                                    </a>
                                </div>
{list type:bt index:2 total:8 title_len:20}
                                <a href="{_url}" class="list_item van-col van-col--12" style="">
                                    <div class="list_box h99">
                                        <div class="list_img van-image" style="overflow: hidden; border-radius: 4px;"><img class="van-image__img" src="/template/{@var:cms_config_tpl_dir}/picture/loading.svg" data-src="{_pic}"></div>
                                    </div>
                                    <div class="listtitle" style="height: 10px;">
                                        <div class="list_title title_line_2 van-multi-ellipsis--l2">{_title}</div>
                                    </div>
                                </a>
{/list}
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
{@include file:footer}
</body>

</html>