<?php exit();?>
link_dblj === 顶部链接 === 顶部链接