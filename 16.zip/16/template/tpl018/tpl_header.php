
    <div class="shadow"></div>
    <header class="header">
        <div class="search easy-autocomplete">
            <form action="/search.php" method="get" class="form">
                <div class="input wrap-input">
                    <input type="text" name="content" placeholder="请在此处输入影片名或演员名称" value autocomplete="off">
                    <button type="submit" class="search-btn" aria-label="Search"><i class="icon-search"></i></button>
                </div>
            </form>
        </div>


        <div class="wrap madou">
            <div class="flex">
                <div class="left-block"><span class="icon-hamb hamb-menu"></span><a href="/" class="logo" onclick="ga('send','event','Link','Click','LOGO图');"><img src="/template/{@var:cms_config_tpl_dir}/picture/93616b853a40cdb086de7ffacce5d8b3.jpg" width="191" height="60"></a></div>
                <nav class="nav">
                    <ul class="menu">
                        <li><a href="/" class="active">网站首页</a></li>
{nav type:video no:v2 count:8} 
                        <li><a href="{_class_link}" style="padding: 10px 5px;">{_class_name}</a></li>
{/nav}
{nav type:bt no:1 count:2 name:国产磁力,日本磁力} 
                        <li><a href="{_class_link}" style="padding: 10px 5px;">{_class_name}</a></li>
{/nav}
                    </ul>
                </nav>
                <div class="right-block"><span class="btn-search link-icon"><span class="icon-search"></span><span class="icon-close"></span></span>
                    <div class="action-log"></div>
                </div>
            </div>
        </div>









    </header>

    <style>
        .col6 {
            position: relative;
            min-height: 1px;
            width: 100%;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }

        .row6 {
            display: flex;
            flex-wrap: wrap;
        }

        @media screen and (max-width:750px) {
            .col6 {
                width: 100% !important;
            }

            .img80 {
                height: 60px !important;
            }

            .img120 {
                height: 90px !important;
            }

            .img160 {
                height: 120px !important;
            }

            .img240 {
                height: 180px !important;
            }
        }

        @media (min-width: 768px) {
            .col6 {
                width: 100%;
            }
        }
    </style>
    <div class="wrap">
        <div class="row6">
        </div>
    </div>

    <style>
        .photo-one {
            display: flex;
            flex-wrap: wrap;
            background-color: rgba(73, 91, 103, 0.37);
            padding-bottom: 10px;
            width: 100%;
            height: 100%;
            margin-top: 10px;
        }

        .photo-two {
            display: inline-block;
            display: block;
            height: 90px;
            margin: 20px;
            text-align: center;
            width: 80px;
        }

        .photo-two a {
            line-height: 20px;
        }

        .photo-two img {
            border-radius: 12%;
            height: 80px;
            width: 80px;
        }

        .photo-name {

            font-weight: bold;
            color: rgb(255, 255, 255);
            font-size: larger;
        }




        @media screen and (max-width:1280px) {
            .photo-two img {
                border-radius: 12%;
                height: 60px;
                width: 60px;
            }
        }



        @media screen and (max-width:980px) {
            .photo-name {
                font-size: 14px;
            }

            .photo-two img {
                border-radius: 12%;
                height: 58px;
                width: 58px;
            }
        }

        @media screen and (max-width:750px) {

            .photo-two {
                width: 18%;
                margin: 10px;
            }
        }
    </style>

<!--     <div class="wrap">
        <div style="display: flex;flex-wrap: wrap;margin-right: 5px;margin-left: 5px;">
            <div class="photo-two"><a href="ch=rh1mls724"  onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': 'TikTok成人版','value': 500});"><img src="/template/{@var:cms_config_tpl_dir}/picture/e620e2f34f85b23b669b3db78d3f87a6.jpg"><br><span class="photo-name" style="color:#FFF;">TikTok成人版</span></a></div>
            <div class="photo-two"><a href="hcom/314pz"  onclick="gtag('event', '小图标', {'event_category': '点击', 'event_label': 'Lutube视频','value': 500});"><img src="/template/{@var:cms_config_tpl_dir}/picture/c0cb4d01e7beb391a03670176670021f.png"><br><span class="photo-name" style="color:#FFF;">Lutube视频</span></a></div>
        </div>
    </div> -->

    <div class="wrap">
        <div class="button2s are-small" style="justify-content: center;">
        </div>
    </div>
    <style>
        .button2 {
            margin: 3px;
            position: relative;
            vertical-align: top;
            line-height: 1.5;
            height: 2.5em;
            box-shadow: none;
            display: inline-flex;
            -webkit-appearance: none;
            align-items: center;
            border: 1px solid transparent;
            background-color: #000;
            border-color: #dbdbdb;
            border-width: 1px;
            color: #fff;
            cursor: pointer;
            justify-content: center;
            padding-bottom: calc(0.5em - 1px);
            padding-left: 1em;
            padding-right: 1em;
            padding-top: calc(0.5em - 1px);
            text-align: center;
            white-space: nowrap;
        }

        .button2.is-danger {
            background-color: #f14668;
            border-color: transparent;
            color: #fff;
        }

        .button2s.are-small .button2:not(.is-normal):not(.is-medium):not(.is-large) {
            border-radius: 2px;
            font-size: 12px;

        }


        @media screen and (max-width:750px) {
            .button2 {
                17%
            }

            .button2s.are-small .button2:not(.is-normal):not(.is-medium):not(.is-large) {
                padding: 1px;
            }


        }
    </style>


<div class="wrap">
{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;margin: 1px 0px;" class="{_class}"></a>
</div>
{/ad}
</div>



    <div class="wrap">
        <div style="width:100%;margin-top: 10px;">
            <ul>
{link area:link_dbdh}
                <li style="width:33%; height:40px; line-height:40px; max-width:140px; text-align:center; border:1px solid #cecece;float:left;background: #;color: #FFA640;">
                    <a rel="nofollow" style=" color: #FFA640; font-size:16px; font-weight:bold;" href="{_url}" target="_blank"><u><span>{base64}{_text}{/base64}</span></u></a>
                </li>
{/link}
            </ul>
            <div style="clear:both;"></div>
        </div>
    </div>

    <div class="wrapped">
        <main>

            <aside class="sidebar">
                <div class="mobile-menu">
                    <ul class="list-link">
                        <li><a href="/" class="active">网站首页</a></li>

{nav type:video no:v2 count:8} 
                        <li><a href="{_class_link}" >{_class_name}</a></li>
{/nav}
{nav type:bt no:1 count:2 name:国产磁力,日本磁力} 
                        <li><a href="{_class_link}">{_class_name}</a></li>
{/nav}


                    </ul>
                </div>
            </aside>