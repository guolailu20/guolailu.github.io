<html>

<head>
    <title>{@page_title}</title>
    <meta name="keywords" content="{@site_keyword}" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,viewport-fit=cover,user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="referrer" content="always">
    <link href="/template/{@var:cms_config_tpl_dir}/css/home.css" rel="stylesheet" type="text/css" />
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.lazyload.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.autocomplete.js"></script>
    <link href="/template/{@var:cms_config_tpl_dir}/css/layui.css" rel="stylesheet" media="all">
    <link rel="stylesheet" type="text/css" href="/template/{@var:cms_config_tpl_dir}/rose/css/style.cssx?_wd=false">
    <link id="layuicss-laydate" rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/laydate.css" media="all">
    <link id="layuicss-layer" rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/layer.css" media="all">
    <link id="layuicss-skincodecss" rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/code.css" media="all">
<link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body style>
{@include file:header}

        <div class="group-box" style="background: rgba(189, 188, 203, 0.4);">
            <p class="group-title">{@name}</p>
            <div class="group-contents layui-row">



<div style="text-align: left; color: white;">
{base64}【影片格式】：mp4<br>
【影片大小】：{@var:torrent_size}<br>
【影片时长】：{@var:torrent_duration}分钟<br>
【分辨率】：{@var:torrent_resolution}<br>
【影片预览】：<br>{/base64}
</div>
<div class="clearfix" style="margin: 0px;">
    {@var:torrent_capture}
</div>

<div style="clear: both;"></div>

<div class="download">
    <div class="hide_mobile">
        <div class="downbtn">
            <a href="{@var:torrent_file_url}" style="width: 100%;">{base64}下载种子{/base64}</a>
        </div>
    </div>
    <div class="downbtn">
        <a href="{@var:torrent_magnet}" style="width: 100%;">{base64}打开磁力{/base64}</a>
    </div>
    <div class="downbtn">
        <a onclick="copyText()" href="javascript:;" style="width: 100%;">{base64}复制磁力{/base64}</a>
    </div>
</div>



<style type="text/css">
.download {
    display: flex;
    justify-content: center;
    color: white;

    margin-top: 20px;
    text-align: center;
    font-size: 20px;
}

.downbtn a  {
    background: ;
    color: white;
    width: 100%;
}

.downbtn {
    display: inline-block;
    background: #FFB800;
    color: white;
    margin: 0px 10px;
    padding: 0 10px;
    font-weight: bold;
}


</style>


<script type="text/javascript">
    function copyText() {
      var text = document.getElementById("torrent_magnet_text").innerText;
      var input = document.getElementById("torrent_magnet_input");
      input.value = text; // 修改文本框的内容
      input.select(); // 选中文本
      document.execCommand("copy"); // 执行浏览器复制命令
      alert("复制成功");
    }
  </script>

<style type="text/css">
   .wrapper2 {position: relative;}
   #torrent_magnet_input {position: absolute;top: 0;left: 0;opacity: 0;z-index: -10;}
</style>

<div class="wrapper2">
   <p id="torrent_magnet_text" style="display: none;">{@var:torrent_magnet}</p>
   <textarea id="torrent_magnet_input"></textarea>
</div>









            </div>
            <div style="width: 100%;">

            </div>
            <div class="group-contents layui-row">
                <div style="width: 100%;"></div>
                <div class="group-box" style="background: rgba(220, 173, 237, 0.4);">
                    <p class="group-title"><i class="layui-icon layui-icon-engine"></i>&nbsp;&nbsp;相关推荐</p>
                    <ul class="group-contents layui-row">
{list type:bt mode:rand total:8 title_len:40}
                        <a href="{_url}"  class="group-item layui-col-md3 m-md6">
                            <img src="/template/{@var:cms_config_tpl_dir}/images/loading.gif" data-src="{_pic}" h="210px">
                            <p>{_title}</p>
                        </a>
{/list}
                    </ul>
                </div>
            </div>
        </div>

{@include file:footer}
</body>

</html>