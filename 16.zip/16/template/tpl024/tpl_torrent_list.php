<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>{@page_title}</title>
    <meta name="renderer" content="webkit" />
    <meta name="force-rendering" content="webkit" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="referrer" content="always">
    <meta name="keywords" content="{@site_keyword}" />
    <meta http-equiv="Cache-Control" content="no-transform">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="MobileOptimized" content="width">
    <meta name="HandheldFriendly" content="true">
    <meta name="author" content="XIAOSISI">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/avv-share.css" media="print" onload="this.media='all'">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/av-103.css" media="print" onload="this.media='all'">
    <link rel="icon" type="image/x-icon" href="/103.svg" />
    <script async defer id="si" web_category="4521904733" src="/template/{@var:cms_config_tpl_dir}/js/analytics.js"></script>

    <script>
        function abcd() {}
    </script>
<link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body style="background:#10241a">



{@include file:header}
        <div class="body">
            <div class="content bottom right">

                <div class="video_list">
                    <div class="ll">
                        <h2>
                            <svg t="1671540559845" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="13612" width="30" height="30">
                                <path d="M896 256l-288 0c-17.696 0-32-14.336-32-32s14.304-32 32-32l288 0c17.696 0 32 14.336 32 32S913.696 256 896 256z" p-id="13613" fill="#e6e6e6"></path>
                                <path d="M896 416l-288 0c-17.696 0-32-14.336-32-32s14.304-32 32-32l288 0c17.696 0 32 14.336 32 32S913.696 416 896 416z" p-id="13614" fill="#e6e6e6"></path>
                                <path d="M896 672l-288 0c-17.696 0-32-14.304-32-32s14.304-32 32-32l288 0c17.696 0 32 14.304 32 32S913.696 672 896 672z" p-id="13615" fill="#e6e6e6"></path>
                                <path d="M896 832l-288 0c-17.696 0-32-14.304-32-32s14.304-32 32-32l288 0c17.696 0 32 14.304 32 32S913.696 832 896 832z" p-id="13616" fill="#e6e6e6"></path>
                                <path d="M384 480 192 480c-52.928 0-96-43.072-96-96L96 192c0-52.928 43.072-96 96-96l192 0c52.928 0 96 43.072 96 96l0 192C480 436.928 436.928 480 384 480zM192 160C174.368 160 160 174.368 160 192l0 192c0 17.632 14.368 32 32 32l192 0c17.632 0 32-14.368 32-32L416 192c0-17.632-14.368-32-32-32L192 160z" p-id="13617" fill="#e6e6e6"></path>
                                <path d="M384 928 192 928c-52.928 0-96-43.072-96-96l0-192c0-52.928 43.072-96 96-96l192 0c52.928 0 96 43.072 96 96l0 192C480 884.928 436.928 928 384 928zM192 608c-17.632 0-32 14.336-32 32l0 192c0 17.664 14.368 32 32 32l192 0c17.632 0 32-14.336 32-32l0-192c0-17.664-14.368-32-32-32L192 608z" p-id="13618" fill="#e6e6e6"></path>
                            </svg>
                            {@class_name} 第{@page_cur}页
                        </h2>

                        <div class="colliu">

{list type:bt mode:list title_len:40}
                            <div class="data" style="height: ;">
                                <a href="{_url}" class="" >
                                    <div class="img">
                                        <img src="{_pic}" loading="lazy" style="height: 140px;"></div>
                                    <p class="title" style="">{_title}</p>
                                </a>
                            </div>
{/list}

                        </div>
                        <div class="pages">
                            <div role="navigation" aria-label="Pagination" class="pagination">
{link_first}<a class="previous_page" aria-label="Previous page" rel="prev" href="{_url}">首页</a>{/link_first}

{links_pre max:3}<a href="{_url}">{_page_no}</a>{/links_pre}
 <em class="current"  aria-current="page">{@page_cur}</em>
{links_next max:3}<a href="{_url}">{_page_no}</a>{/links_next}

{link_last}<a class="next_page"  rel="next" href="{_url}">尾页</a>{/link_last}


                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>

{@include file:footer}

</body>

</html>