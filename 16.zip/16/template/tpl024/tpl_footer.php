
        
        <div class="body">

<!--             <div class="new_foot_links">
                <h2>合作伙伴</h2>
                <a class="jzhh" href="httpn/"  style=""></a>
                <a class="jzhh" href="htt.com"  style=""></a>
            </div> -->

            <div class="content foot">
                <p class="blkg">@
                    Email:</p>
                <p>本站遵守美國法律，僅對美籍華裔人士開放。禁止未成年人、當地法律不允許以及中國大陸地區等人群訪問。</p>
                <p>本站內容由程序自動採集，若有侵權，請立即聯繫刪除。</p>
                <p>This site complies with US law. Open to Chinese Americans only. Access by minors, those not allowed by local laws, and those in mainland China is prohibited.</p>
                <p>The content of this site is automatically collected by the program. If there is any infringement, please contact us immediately to delete it.</p>
            </div>

        </div>
    </div>




{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}