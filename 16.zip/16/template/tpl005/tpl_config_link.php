<?php exit();?>
link_zztj === 站长推荐 === 位于栏目导航下方
link_hzhb === 合作伙伴 === 位于栏目导航下方
link_yqlj === 友情链接 === 位于页面底部