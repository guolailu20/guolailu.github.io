<?php exit();?>
video_page_size === hide === 列表显示内容的数量 === 20
bt_page_size === hide === 列表显示内容的数量 === 20
bottom_statement === textarea === 底部声明 === 免责声明：若本站收录的资源侵犯了您的权益，请联系<br>飞机号：@<br>邮箱：<br>们会及时删除侵权内容，谢谢合作，本站每日更新。

link_fix_url  ===  text   === 地址发布  === javascript:void(0);
link_contact  ===  text   === 联系我们  === javascript:void(0);
link_adv  ===  text   === 投放广告  === javascript:void(0);
link_backup_url  ===  text   === 备用地址  === javascript:void(0);