<?php exit();?>
link_tjdh === 名站导航 === 位于页面顶部
link_yqlj === 友情链接 === 位于页面底部