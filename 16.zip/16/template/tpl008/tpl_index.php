<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <title>{@page_title}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <link href="/template/{@var:cms_config_tpl_dir}/css/main.min.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery.min2.2.4.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
    <style>
        .pagination ul {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
        }

        .pagination ul li {
            display: inline;
        }

        .pagination ul li a {
            float: left;
            background-color: #ffffff !important;
            color: #4a545a !important;
            height: 32px;
            font-size: 22px;
            line-height: 32px;
            margin-bottom: 8px !important;
            margin-right: 8px !important;
            position: relative;
            display: inline-block;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            min-width: 58px;
            margin: 0;
            padding: 0 16px;
            overflow: hidden;
            font-weight: 500;
            letter-spacing: .04em;
            white-space: nowrap;
            text-align: center;
            text-transform: uppercase;
            text-decoration: none;
            vertical-align: middle;
            background: 0 0;
            border: none;
            border-radius: 2px;
            outline: 0;
            cursor: pointer;
            -webkit-transition: all .2s cubic-bezier(.4, 0, .2, 1), -webkit-box-shadow .2s cubic-bezier(.4, 0, 1, 1);
            transition: all .2s cubic-bezier(.4, 0, .2, 1), -webkit-box-shadow .2s cubic-bezier(.4, 0, 1, 1);
            transition: all .2s cubic-bezier(.4, 0, .2, 1), box-shadow .2s cubic-bezier(.4, 0, 1, 1);
            transition: all .2s cubic-bezier(.4, 0, .2, 1), box-shadow .2s cubic-bezier(.4, 0, 1, 1), -webkit-box-shadow .2s cubic-bezier(.4, 0, 1, 1);
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
            will-change: box-shadow;
            zoom: 1;
            -webkit-user-drag: none;
        }

        .pagination ul a.dqy,
        .pagination ul a:hover {
            background-color: #37bf91 !important;
            color: #ffffff !important;
        }

        @media screen and (max-width: 48em) {
            .navbar {
                display: block;
            }

            .nav_left {
                width: 25%;
                float: left;
            }

            .navbar__logo {
                width: 50%;
                float: left;
            }

            .nav_right {
                float: right;
            }

            .logo__mark {
                line-height: 1.375em;
            }
        }

        @media (max-width: 30em) {
            .cards__item {
                width: 50%;
            }
        }
        }
    </style>
    {@common_head}
</head>

<body class="page finished loaded">


    {@include file:header}

    

        <main class="page__main">
            <div class="cards">
                <div class="container container--big">
                    <div class="heading">
                        <div class="heading__item">
                            <a href="{@class_link type:video index:1}">
                            <h1 class="heading__title">
                                {base64}{@class_name type:video index:1}{/base64}
                            </h1>
                            </a>
                        </div>
                    </div>
                    <div class="cards__list" data-items="true">
                        {list type:video index:1 total:8 title_len:40}
                        <div class="cards__item cards_common" data-item-id="69408">
                            <a href="{_url}" class="card">
                                <span class="card__content">
                                    <img src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}" class="card__image lazy"/>
                                    <span class="card__icon">
                                        <svg class="icon icon--play" width="32px" height="32px">
                                            <use xlink:href="/template/{@var:cms_config_tpl_dir}/fonts/site.svg#play"></use>
                                        </svg>
                                    </span>
                                </span>
                                <span class="card__footer">
                                    <span class="card__title">{_title}</span>
                                </span>
                            </a>
                        </div>
                        {/list}
                    </div>
                </div>



                <div class="container container--big">
                    <div class="heading">
                        <div class="heading__item">
                            <a href="{@class_link type:video index:2}">
                            <h1 class="heading__title">
                                {base64}{@class_name type:video index:2}{/base64}
                            </h1>
                            </a>
                        </div>
                    </div>
                    <div class="cards__list" data-items="true">
                        {list type:video index:2 total:8 title_len:40}
                        <div class="cards__item cards_common" data-item-id="69408">
                            <a href="{_url}" class="card">
                                <span class="card__content">
                                    <img src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}" class="card__image lazy"/>
                                    <span class="card__icon">
                                        <svg class="icon icon--play" width="32px" height="32px">
                                            <use xlink:href="/template/{@var:cms_config_tpl_dir}/fonts/site.svg#play"></use>
                                        </svg>
                                    </span>
                                </span>
                                <span class="card__footer">
                                    <span class="card__title">{_title}</span>
                                </span>
                            </a>
                        </div>
                        {/list}
                    </div>
                </div>





                <div class="container container--big">
                    <div class="heading">
                        <div class="heading__item">
                            <a href="{@class_link type:video index:4}">
                            <h1 class="heading__title">
                                {base64}{@class_name type:video index:4}{/base64}
                            </h1>
                            </a>
                        </div>
                    </div>
                    <div class="cards__list" data-items="true">
                        {list type:video index:4 total:8 title_len:40}
                        <div class="cards__item cards_common" data-item-id="69408">
                            <a href="{_url}" class="card">
                                <span class="card__content">
                                    <img src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}" class="card__image lazy"/>
                                    <span class="card__icon">
                                        <svg class="icon icon--play" width="32px" height="32px">
                                            <use xlink:href="/template/{@var:cms_config_tpl_dir}/fonts/site.svg#play"></use>
                                        </svg>
                                    </span>
                                </span>
                                <span class="card__footer">
                                    <span class="card__title">{_title}</span>
                                </span>
                            </a>
                        </div>
                        {/list}
                    </div>
                </div>





                <div class="container container--big">
                    <div class="heading">
                        <div class="heading__item">
                            <a href="{@class_link type:video index:3}">
                            <h1 class="heading__title">
                                {base64}{@class_name type:video index:3}{/base64}
                            </h1>
                            </a>
                        </div>
                    </div>
                    <div class="cards__list" data-items="true">
                        {list type:video index:3 total:8 title_len:40}
                        <div class="cards__item cards_common" data-item-id="69408">
                            <a href="{_url}" class="card">
                                <span class="card__content">
                                    <img src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}" class="card__image lazy"/>
                                    <span class="card__icon">
                                        <svg class="icon icon--play" width="32px" height="32px">
                                            <use xlink:href="/template/{@var:cms_config_tpl_dir}/fonts/site.svg#play"></use>
                                        </svg>
                                    </span>
                                </span>
                                <span class="card__footer">
                                    <span class="card__title">{_title}</span>
                                </span>
                            </a>
                        </div>
                        {/list}
                    </div>
                </div>





                <div class="container container--big">
                    <div class="heading">
                        <div class="heading__item">
                            <a href="{@class_link type:torrent index:1}">
                            <h1 class="heading__title">
                                {base64}国产磁力{/base64}
                            </h1>
                            </a>
                        </div>
                    </div>
                    <div class="cards__list" data-items="true">
                        {list type:bt index:1 total:8 title_len:40}
                        <div class="cards__item cards_common" data-item-id="69408">
                            <a href="{_url}" class="card">
                                <span class="card__content">
                                    <img src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}" class="card__image lazy"/>
                                    <span class="card__icon">
                                        <svg class="icon icon--play" width="32px" height="32px">
                                            <use xlink:href="/template/{@var:cms_config_tpl_dir}/fonts/site.svg#play"></use>
                                        </svg>
                                    </span>
                                </span>
                                <span class="card__footer">
                                    <span class="card__title">{_title}</span>
                                </span>
                            </a>
                        </div>
                        {/list}
                    </div>
                </div>



                <div class="container container--big">
                    <div class="heading">
                        <div class="heading__item">
                            <a href="{@class_link type:torrent index:2}">
                            <h1 class="heading__title">
                                {base64}日本种子{/base64}
                            </h1>
                            </a>
                        </div>
                    </div>
                    <div class="cards__list" data-items="true">
                        {list type:bt index:2 total:8 title_len:40}
                        <div class="cards__item cards_common" data-item-id="69408">
                            <a href="{_url}" class="card">
                                <span class="card__content">
                                    <img src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" data-original="{_pic}" class="card__image lazy"/>
                                    <span class="card__icon">
                                        <svg class="icon icon--play" width="32px" height="32px">
                                            <use xlink:href="/template/{@var:cms_config_tpl_dir}/fonts/site.svg#play"></use>
                                        </svg>
                                    </span>
                                </span>
                                <span class="card__footer">
                                    <span class="card__title">{_title}</span>
                                </span>
                            </a>
                        </div>
                        {/list}
                    </div>
                </div>
            </div>
        </main>


{@include file:footer}
</body>

</html>