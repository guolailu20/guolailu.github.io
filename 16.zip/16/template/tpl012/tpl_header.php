    <div class="fundo"></div>
    <header class="topo">
        <div class="container">
            <div class="topo-conteudo">
        
                <div class="topo-logo">
                    <button class="botao-menu" id="botao-menu" style=""><i class="bg-bars_solid"></i></button>
                    <a title="" href="/"><span class="logo-nome">{@site_name}</span></a>
                    <button class="botao-busca" onclick="mostraDiv('busca')">
                        <i class="bg-search_solid"></i>
                    </button>
                </div>
                <!-- <div class="topo-titulo"> 最新网址: <span></span>
                </div> -->
                <div class="busca" id="busca">
                    <form method="get" action="/search.php">
                        <input type="text" name="content" placeholder="输入关键字..." value="" />
                        <button type="submit" class="busca-submit">
                            <i class="bg-search_solid_black"></i>
                            <span>搜索</span>
                        </button>
                    </form>
                </div>
                <div class="clearfix"></div>
                <div class="topo-menu" id="topo-menu" style="">
                    <ul id="menu-menu" class="menu">
                        <li class="menu-item-1" class="menu-item">
                            <a href="/" rel="nofollow">网站首页</a>
                        </li>
                        {nav type:video no:v2 count:6}
                        <li class="menu-item">
                            <a href="{_class_link}" rel="nofollow">{_class_name}</a>
                        </li>
                        {/nav}
                        {nav type:bt no:1 count:2 name:国产磁力,日本磁力}
                        <li class="menu-item">
                            <a href="{_class_link}" rel="nofollow">{_class_name}</a>
                        </li>
                        {/nav}
                    </ul>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="clearfix"></div>
    </header>


    <div class="meio">
        <div class="container">
            

{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;" class="{_class}"></a>
</div>
{/ad}

        </div>
    </div>



    
    <style>
        .row {
            display: flex;
            flex-wrap: wrap;
            margin-right: -7.5px;
            margin-left: -7.5px;
        }

        @media (min-width: 768px) {
            .row {
                margin-right: -18px;
                margin-left: -18px;
            }
        }

        .quadra-box {
            flex: 0 0 20%;
            max-width: 20%;
            padding-right: 7.5px;
            padding-left: 7.5px;
            position: relative;
            width: 100%;
            margin-bottom: 0px;
        }

        .quadra-box img {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: block;
            margin: 0 auto;
        }

        .quadra-box p {
            margin: 10px 0;
            text-align: center;
        }

        @media (min-width: 1170px) {
            .quadra-box {
                flex: auto;
                max-width: 85px;
                padding-right: 7.5px;
                padding-left: 7.5px;
                position: relative;
                width: 100%;
                margin-bottom: 0px;
            }
        }

        @media (min-width: 768px) {
            .quadra-box img {
                width: 60px;
                height: 60px;
                border-radius: 5px;
            }
        }

        @media (min-width: 768px) {
            .quadra-box p {
                margin: 15px 0;
            }
        }

        .text-truncate {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
    <div class="container" style="margin-top: 20px;">
<!--         <div class="row">
            <div class="quadra-box">
                <a class="bd-link andro_link ck_x link-show" data-id="1480" href="https://2a6e70.csmendh11.com" rel="nofollow" target="_blank">
                    <img class="enc_img lazyload" data-src="/template/{@var:cms_config_tpl_dir}/picture/125849261.png" src="/template/{@var:cms_config_tpl_dir}/picture/lazysizes.svg">
                    <p class="text-truncate">传送门</p>
                </a>
            </div>
            <div class="quadra-box">
                <a class="bd-link andro_link ck_x link-show" data-id="1491" href="https://t鋀24鲗灨ox.toxinzeai.xyz/go/" rel="nofollow" target="_blank">
                    <img class="enc_img lazyload" data-src="/template/{@var:cms_config_tpl_dir}/picture/173750351.gif" src="/template/{@var:cms_config_tpl_dir}/picture/lazysizes.svg">
                    <p class="text-truncate">偷心贼</p>
                </a>
            </div>
        </div> -->
        <style>
            .txtgg {
                width: 100%;
                overflow: hidden;
                display: block;
                box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .05);
            }

            .txtgg a {
                width: 9.78%;
                float: left;
                border-radius: 3px;
                line-height: 30px;
                height: 30px;
                text-align: center;
                font-size: 14px;
                color: #fff;
                display: inline-block;
                background-color: #ff0000;
                margin: 1px;
                transition-duration: .3s;
            }

            .txtgg a:nth-child(1) {
                background-color: #FF3366;
            }

            .txtgg a:nth-child(2) {
                background-color: #ffab00;
            }

            .txtgg a:nth-child(3) {
                background-color: #33CCFF;
            }

            .txtgg a:nth-child(4) {
                background-color: #66CC00;
            }

            .txtgg a:nth-child(5) {
                background-color: #fb3939;
            }

            .txtgg a:nth-child(6) {
                background-color: #ff00f1;
            }

            .txtgg a:nth-child(7) {
                background-color: #ff0000;
            }

            .txtgg a:nth-child(8) {
                background-color: #2b36ff;
            }

            .txtgg a:nth-child(9) {
                background-color: #00a90a;
            }

            .txtgg a:nth-child(10) {
                background-color: #ff6600;
            }

            .txtgg a:nth-child(11) {
                background-color: #ff0040;
            }

            .txtgg a:nth-child(12) {
                background-color: #ff7c00;
            }

            .txtgg a:nth-child(13) {
                background-color: #006c82;
            }

            .txtgg a:nth-child(14) {
                background-color: #77674b;
            }

            .txtgg a:nth-child(15) {
                background-color: #996699;
            }

            .txtgg a:nth-child(16) {
                background-color: #666666;
            }

            .txtgg a:nth-child(17) {
                background-color: #006699;
            }

            .txtgg a:nth-child(18) {
                background-color: #993333;
            }

            .txtgg a:nth-child(19) {
                background-color: #993333;
            }

            .txtgg a:nth-child(20) {
                background-color: #333300;
            }

            .txtgg a:nth-child(21) {
                background-color: #663366;
            }

            .txtgg a:nth-child(22) {
                background-color: #003300;
            }

            .txtgg a:nth-child(23) {
                background-color: #003366;
            }

            .txtgg a:nth-child(24) {
                background-color: #996699;
            }

            .txtgg a:nth-child(25) {
                background-color: #666666;
            }

            .txtgg a:nth-child(26) {
                background-color: #006699;
            }

            .txtgg a:nth-child(27) {
                background-color: #993333;
            }

            .txtgg a:nth-child(28) {
                background-color: #6593b7;
            }

            .txtgg a:nth-child(29) {
                background-color: #96593e;
            }

            .txtgg a:nth-child(30) {
                background-color: #3e9096;
            }

            .txtgg a:hover {
                background: #DC3545;
                color: #FFF
            }

            @media screen and (max-width: 1000px) {
                .txtgg a {
                    width: 19.4%;
                    float: left;
                    border-radius: 3px;
                    line-height: 30px;
                    height: 30px;
                    text-align: center;
                    font-size: 12px;
                    color: #fff;
                    display: inline-block;
                    background-color: #ff0000;
                    margin: 1px;
                    transition-duration: .3s;
                }
            }
        </style>
        <div class="txtgg">
{link area:link1}
<a data-id="1480" href="{_url}" target="_blank" rel="nofollow" class="dh" style="text-decoration: none">{base64}{_text}{/base64}</a>
{/link}
        </div>
        <style>
            .txtgg2 {
                width: 100%;
                overflow: hidden;
                display: block;
                box-shadow: 0 1px 1px 0 rgba(0, 0, 0, .05);
            }

            .txtgg2 a {
                width: 9.78%;
                float: left;
                border-radius: 3px;
                line-height: 30px;
                height: 30px;
                text-align: center;
                font-size: 14px;
                color: #fff;
                display: inline-block;
                background-color: #333;
                margin: 1px;
                transition-duration: .3s;
            }

            .txtgg2 a:hover {
                background: #000;
                color: #FFF
            }

            @media screen and (max-width: 1000px) {
                .txtgg2 a {
                    width: 19.4%;
                    float: left;
                    border-radius: 3px;
                    line-height: 30px;
                    height: 30px;
                    text-align: center;
                    font-size: 12px;
                    color: #fff;
                    display: inline-block;
                    background-color: #333;
                    margin: 1px;
                    transition-duration: .3s;
                }
            }
        </style>
<!--         <h3><i class="iconfont icon-aqq"></i> 合作伙伴</h3>
        <div class="txtgg2">
            <a data-id="1490" href="https://耕刺擝z.d6g301.com/呐月m3" target="_blank" rel="nofollow" class="dh" style="text-decoration: none">第6感导航</a>
            <a data-id="2601" href="https://dahu3.xyz/kwUQnv" target="_blank" rel="nofollow" class="dh" style="text-decoration: none">杏Map</a>
        </div> -->
        <style>
            .grid-container {
                display: grid;
                grid-template-columns: auto auto auto auto auto auto auto auto auto auto auto auto auto auto auto auto;
                padding: 2px;
            }

            .grid-item {
                background-color: #2e2e2e;
                padding: 5px;
                font-size: 14px;
                text-align: center;
                margin: 2px;
                border-radius: 10px;
            }

            .grid-item a {
                text-decoration: none;
                color: #f7d0bf;
            }

            @media only screen and (max-width: 1400px) {
                .grid-item {
                    font-size: 16px;
                }

                .grid-container {
                    grid-template-columns: auto auto auto auto auto auto auto auto auto auto auto auto;
                }
            }

            @media only screen and (max-width: 500px) {
                .grid-item {
                    font-size: 13px;
                }

                .grid-container {
                    grid-template-columns: auto auto auto auto auto auto auto auto;
                }
            }
        </style>
        <h3><i class="iconfont icon-hot"></i> 热搜种子</h3>
        <div class="grid-container">
{splite var:search_tags_torrent}
            <div class="grid-item" style="background: #;"><a class="" href="/search.php?content=b64{_var_b64}&type=2">{base64}{_var}{/base64}</a></div>
{/splite}
        </div>
    </div>

