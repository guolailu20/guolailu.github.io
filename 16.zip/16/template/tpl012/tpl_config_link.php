<?php exit();?>
link1 === 顶部彩色链接 === 
link2 === 底部友情链接 === 