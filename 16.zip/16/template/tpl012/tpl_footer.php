


            <h3><i class="iconfont icon-link"></i> 友情链接</h3>
            <ul id="menu-rodape-links" class="rodape-categorias">
{link area:link1}
<li class="menu-item"><a target="_blank" href="{_url}" target="">{base64}{_text}{/base64}</a></li>
{/link}


            </ul>
        </div>
    </div>
    <div class="rodape">
        <div class="container">
            <div class="rodapeBloco"></div>
            <div class="copy">聲明：本站已按臺灣網路內容分級製度處理，未滿18歲或者當地法律不允許禁止瀏覽本站。</div>
        </div>
    </div>
    <noscript>
        <style>
            .lazyload {
                display: none
            }
        </style>
    </noscript>
    <script src='/template/{@var:cms_config_tpl_dir}/js/jquery.min.js'></script>
    <script data-noptimize="1">
        window.lazySizesConfig = window.lazySizesConfig || {};
        window.lazySizesConfig.loadMode = 1;
    </script>
    <script async data-noptimize="1" src='/template/{@var:cms_config_tpl_dir}/js/lazysizes.min.js'></script>
    <script src='/template/{@var:cms_config_tpl_dir}/js/autoptimize.js'></script>



{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}



