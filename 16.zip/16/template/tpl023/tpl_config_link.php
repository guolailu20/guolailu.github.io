<?php exit();?>
link1 === 顶部导航 === 顶部导航