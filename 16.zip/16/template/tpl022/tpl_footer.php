

<!--     <div style="height:1rem"></div>
    <div id="link" class="block">
        <div id="title">友情链接</div>
        <ul>
            <div class="clear"></div>
        </ul>
    </div> -->
    <script src="/template/{@var:cms_config_tpl_dir}/js/fa46f652-665a-850-34-6e1b1cada166.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/1874c736-d77a-851-33-4eac257ebfcd.js"></script>
    <div class="footer">
        <div class="fBox">
            <p>
                {base64}本網站已依網站內容分級規定處理，請先確定您已年滿法律許可之法定年齡！如果您是未滿18歲者或對成人情色反感，請勿參訪本站！{/base64}
            </p>
        </div>
    </div>
    <div class="index-top" id="index-top">
        <a class="top"></a>
    </div>


{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}