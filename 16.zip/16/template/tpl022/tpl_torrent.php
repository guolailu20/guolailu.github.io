<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8">
    <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no" id="viewport" name="viewport">
    <title>{@page_title}</title>
    <meta name="keywords" content="{@site_keyword}" />
    <meta content="telephone=no" name="format-detection">
    <meta name="applicable-device" content="pc,mobile">
    <meta name="MobileOptimized" content="width">
    <meta name="HandheldFriendly" content="true">
    <meta content="{cms_title}" name="apple-mobile-web-app-title">
    <meta name="referrer" content="always">
    <link type="text/css" rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/index.css?4">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/a_wap.css">
    <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery-lazyload.js"></script>
    <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery.base.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/home.js"></script>
<link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css">
<script src="/template/{@var:cms_config_tpl_dir}/js/common.js" type="application/javascript"></script>
{@common_head}
</head>

<body>
{@include file:header}

    <div class="list_nav" style="border:none">
        <div class="list_nav" style="border:none;margin: 5px;">
            <div class="main fn-left"><span>{@name}</span>
                
            </div>
        </div>
        <div class="video-player-dom clearfix">
            <div class="col-md-12">
                <div style="height:;width:100%;padding-bottom:;position:;background:">
                    <div style="position:;top:0;bottom:0;left:0;right:0">


<div style="text-align: left;font-size: 16px;">
{base64}【影片格式】：mp4<br>
【影片大小】：{@var:torrent_size}<br>
【影片时长】：{@var:torrent_duration}分钟<br>
【分辨率】：{@var:torrent_resolution}<br>
【影片预览】：<br>{/base64}
</div>
<div class="clearfix" style="margin: 0px; width: 98%;" >
    {@var:torrent_capture}
</div>

<div style="clear: both;"></div>

<div class="download">
        <div class="downbtn hide_mobile">
            <a href="{@var:torrent_file_url}" style="width: 100%;">{base64}下载种子{/base64}</a>
        </div>
    <div class="downbtn">
        <a href="{@var:torrent_magnet}" style="width: 100%;">{base64}打开磁力{/base64}</a>
    </div>
    <div class="downbtn">
        <a onclick="copyText()" href="javascript:;" style="width: 100%;">{base64}复制磁力{/base64}</a>
    </div>
</div>

<div style="float: left; clear: both;"></div>
<div style="text-align: left;">

    <div class="hide_mobile" style="padding: 10px;">
        <a style="font-size: 16px; color:#111 ;" href='{@var:api_config_bt_client_pc_download_url}' target='_blank'>{@var:api_config_bt_client_pc_download_text}</a>
    </div>

    <div class="hide_pc" style="padding: 10px;">
        <a style="font-size: 16px; color:#111 ;" href='{@var:api_config_bt_client_mobile_download_url}'>{@var:api_config_bt_client_mobile_download_text}</a>
    </div>
</div>


<style type="text/css">
.download {
    display: flex;
    justify-content: center;
    color: white;

    margin-top: 20px;
    text-align: center;
    font-size: 20px;
}

.downbtn a  {
    background: red;
    color: white;
    width: 100%;
}

.downbtn {
    display: inline-block;
    background: red;
    color: white;
    margin: 0px 10px;
    padding: 0 10px;
    font-weight: bold;
}


</style>


<script type="text/javascript">
    function copyText() {
      var text = document.getElementById("torrent_magnet_text").innerText;
      var input = document.getElementById("torrent_magnet_input");
      input.value = text; // 修改文本框的内容
      input.select(); // 选中文本
      document.execCommand("copy"); // 执行浏览器复制命令
      alert("复制成功");
    }
  </script>

<style type="text/css">
   .wrapper2 {position: relative;}
   #torrent_magnet_input {position: absolute;top: 0;left: 0;opacity: 0;z-index: -10;}
</style>

<div class="wrapper2">
   <p id="torrent_magnet_text" style="display: none;">{@var:torrent_magnet}</p>
   <textarea id="torrent_magnet_input"></textarea>
</div>





                    </div>
                </div>
            </div>
        </div>

        <div style="clear: both;"></div>

        <div class="main vod-botx-title">
            <ul>
                <li id="latest1" onclick="setTab('latest',1,3);" class="current">猜你喜欢</li>
            </ul>
        </div>
        <div class="main" id="resize_list">
            <div class="all_tab" style="border-bottom:none" id="con_latest_1" style="display:block">
                <ul class="list_tab_img">


{list type:bt mode:rand total:12 title_len:22}
                    <li><a href="{_url}">
                            <div class="picsize">
                                <img style="height: 160px;" class="loading" src="{_pic}">
                            </div>
                        </a>
                        <h6 style="line-height: 20px; height: 40px;"><a href="{_url}" target="_self">{_title}</a></h6>
                    </li>
{/list}





                </ul>
            </div>
        </div>


{@include file:footer}

</body>

</html>