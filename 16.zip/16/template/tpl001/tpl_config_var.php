<?php exit();?>
video_page_size === hide === 列表显示内容的数量 === 20
bt_page_size === hide === 列表显示内容的数量 === 20
logo === text === logo图标 === /template/tpl001/image/logo.png
search_tags === textarea === 搜索框后面的推荐搜索词，多个词之间用半角分隔线|分开 === 大神|探花|大圈|高端|良家|泡良|绿帽|换妻|单男|交换|淫妻|MJ|迷奸|灌醉|下药|车模|下海|Avove|吞精|模特|空姐|调教
fix_domain === text === 永久地址 === http://madou.com
correct_domain === text === 顶部Logo下方的正确网址 === <i>https://</i>madou.com
apple_app_url === text ===  顶部苹果APP地址 === 
android_app_url === text === 顶部安卓APP地址 === 
share_text_base64 === text === 顶部分享好友 === https://madou.com 提示：请勿在微信和QQ中打开。尽量使用谷歌浏览器，火狐浏览器，或者苹果安卓系统自带浏览器访问～
backhome_email === text === 顶部找回域名邮箱 === mailto:123@qq.com
cooperation === text === 底部合作加盟 === https://t.me/sycms
qa === text === 底部常见问题 === https://t.me/sycms
service === text === 底部在线客服 === https://t.me/sycms
telegram === text === 底部加入电报 === https://t.me/sycms
