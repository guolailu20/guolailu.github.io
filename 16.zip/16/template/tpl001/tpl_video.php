﻿<?php exit();?><!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <title>{@page_title}</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-type" name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width">
        <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css?3">
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/search.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/common.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/base.js"></script>
        {@common_head}
    </head>
    
    <body ontouchstart="" style="">
        {@include file:header}

        <div class="wrap">
            <div class="main">
                <h1 id="titleH">{@name}</h1>
                <div class="content clearfix">
                    <div class="player">
                        <div class="player-wrap">
                            <div class="player-box">
                                <div id="player" style="width:100%;height:100%;">
                                    <script src="https://cdn.jsdelivr.net/hls.js/latest/hls.min.js"></script>
                                    <video class="player-box" src="{@m3u8}" id="video"  controls autoplay></video>
                                    <script>
                                        if (Hls.isSupported()) {
                                            var video = document.getElementById('video'); // 获取 video 标签
                                            var hls = new Hls(); // 实例化 Hls 对象
                                            hls.loadSource('{@m3u8}'); // 传入路径
                                            hls.attachMedia(video);
                                            hls.on(Hls.Events.MANIFEST_PARSED, function () {
                                                video.play(); // 调用播放 API
                                            });
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wrap">
            <div class="mod play-list">
                <div class="title">
                    <h3>猜你喜欢视频</h3></div>
                <div class="row col5 clearfix" id="cnxh">
                    {list type:video mode:rand total:10 title_len:24}
                    <dl>
                        <dt>
                            <a href="{_url}" title="">
                                <img class="nature" src="{_pic}" data-original="{_pic}" alt="" style="transition: all 1s ease 0s; opacity: 1;">
                                <i>
                                </i>
                            </a>
                        </dt>
                        <dd>
                            <a href="{_url}" title="">
                                <h3>{_title}</h3></a>
                        </dd>
                    </dl>
                    {/list}
                </div>
            </div>
        </div>
        {@include file:footer}
    </body>
</html>