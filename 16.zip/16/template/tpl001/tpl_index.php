<?php exit();?><!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <title>{@page_title}</title>
        <meta http-equiv="keywords" content="{@site_keyword}">
        <meta http-equiv="description" content="{@site_desc}">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-type" name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width">
        <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/style.css?3">
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/search.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/common.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/base.js"></script>
        {@common_head}
    </head>
    
    <body ontouchstart="" style="overflow: auto;">
        {@include file:header}
        <div class="wrap">
            <div class="mod index-list">
                <div class="title">
                    <h3>
                        <i class="icon-fire"></i>
                        <a href="{@class_link type:video index:3}">{@class_name type:video index:3}</a></h3>
                    <a class="total" href="{@class_link type:video index:3}">查看更多&gt;&gt;</a></div>
                <div class="row col5 clearfix" id="">
                    {list type:video index:3 total:10 title_len:24}
                    <dl>
                        <dt>
                            <a href="{_url}" target="_blank" title="">
                                <img class="nature" src="{_pic}" data-original="{_pic}" alt=""></a>
                        </dt>
                        <dd>
                            <a href="{_url}" target="_blank" title="">
                                <h3>{_title}</h3></a>
                        </dd>
                    </dl>
                    {/list}
                </div>
            </div>
        </div>

        <div class="wrap">
            <div class="mod index-list">
                <div class="title">
                    <h3>
                        <i class="icon-fire"></i>
                        <a href="{@class_link type:video index:4}">{@class_name type:video index:4}</a></h3>
                    <a class="total" href="{@class_link type:video index:4}">查看更多&gt;&gt;</a></div>
                <div class="row col5 clearfix" id="">
                    {list type:video index:4 total:10 title_len:24}
                    <dl>
                        <dt>
                            <a href="{_url}" target="_blank" title="" target="_blank">
                                <img class="nature" src="{_pic}" data-original="{_pic}" alt=""></a>
                        </dt>
                        <dd>
                            <a href="{_url}" target="_blank" title="" target="_blank">
                                <h3>{_title}</h3></a>
                        </dd>
                    </dl>
                    {/list}
                </div>
            </div>
        </div>

        <div id="homeWrap">
            <div class="wrap">
                <div class="mod index-list">
                    <div class="title">
                        <h3>
                            <i class="icon-fire"></i>
                            <a href="{@class_link type:video index:1}">{@class_name type:video index:1}</a></h3>
                        <a class="total" href="{@class_link type:video index:1}">查看更多&gt;&gt;</a></div>
                    <div class="row col5 clearfix" id="">
                        {list type:video index:1 total:10 title_len:24}
                        <dl>
                            <dt>
                                <a href="{_url}" target="_blank" title="">
                                    <img class="nature" src="{_pic}" data-original="{_pic}" alt=""></a>
                            </dt>
                            <dd>
                                <a href="{_url}" target="_blank" title="">
                                    <h3>{_title}</h3></a>
                            </dd>
                        </dl>
                        {/list}
                    </div>
                </div>
            </div>
        </div>

        <div class="wrap">
            <div class="mod index-list">
                <div class="title">
                    <h3>
                        <i class="icon-fire"></i>
                        <a href="{@class_link type:video index:2}">{@class_name type:video index:2}</a></h3>
                    <a class="total" href="{@class_link type:video index:2}">查看更多&gt;&gt;</a></div>
                <div class="row col5 clearfix" id="">
                    {list type:video index:2 total:10 title_len:24}
                    <dl>
                        <dt>
                            <a href="{_url}" target="_blank" title="">
                                <img class="nature" src="{_pic}" data-original="{_pic}" alt=""></a>
                        </dt>
                        <dd>
                            <a href="{_url}" target="_blank" title="">
                                <h3>{_title}</h3></a>
                        </dd>
                    </dl>
                    {/list}
                </div>
            </div>
        </div>

        <div class="wrap">
            <div class="mod index-list">
                <div class="title">
                    <h3>
                        <i class="icon-fire"></i>
                        <a href="{@class_link type:bt index:1}">{base64}国产种子{/base64}</a></h3>
                    <a class="total" href="{@class_link type:bt index:1}">查看更多&gt;&gt;</a></div>
                <div class="row col5 clearfix" id="">
                    {list type:bt index:1 total:10 title_len:24}
                    <dl>
                        <dt>
                            <a href="{_url}" target="_blank" title="" target="_blank">
                                <img class="nature" src="{_pic}" data-original="{_pic}" alt=""></a>
                        </dt>
                        <dd>
                            <a href="{_url}" target="_blank" title="" target="_blank">
                                <h3>{_title}</h3></a>
                        </dd>
                    </dl>
                    {/list}
                </div>
            </div>
        </div>

        <div class="wrap">
            <div class="mod index-list">
                <div class="title">
                    <h3>
                        <i class="icon-fire"></i>
                        <a href="{@class_link type:bt index:2}">{base64}日本磁力{/base64}</a></h3>
                    <a class="total" href="{@class_link type:bt index:1}">查看更多&gt;&gt;</a></div>
                <div class="row col5 clearfix" id="">
                    {list type:bt index:2 total:10 title_len:24}
                    <dl>
                        <dt>
                            <a href="{_url}" target="_blank" title="" target="_blank">
                                <img class="nature" src="{_pic}" data-original="{_pic}" alt=""></a>
                        </dt>
                        <dd>
                            <a href="{_url}" target="_blank" title="" target="_blank">
                                <h3>{_title}</h3></a>
                        </dd>
                    </dl>
                    {/list}
                </div>
            </div>
        </div>

        {@include file:footer}

    </body>
</html>