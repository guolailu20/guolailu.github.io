<?php exit();?>
link_yqlj === 友情链接 === 位于页面顶部
link_hzhb === 合作伙伴 === 位于页面底部