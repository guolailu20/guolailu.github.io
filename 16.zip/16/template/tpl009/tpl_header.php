    <div class="site" id="page" style="max-width: 1344px;margin: 0 auto;">



                            {ad area:hengfu1}
                            <div style="width: 100%;margin: 1px 0px;" class="{_class}">
                            <dl style="margin: 0px;" class="{_class}">
                            <dt class="{_class}">
                                <a href="{_url}" target="_blank" rel="nofollow"  class="{_class}">
                                    <img src="{_image}" class="{_class}" style="width: 100%;"></a>
                            </dt></dl>
                        </div>
                            {/ad}

        <div id="wrapper-navbar" itemscope itemtype="http://schema.org/WebSite">
            <a class="skip-link sr-only sr-only-focusable" href="#content">Skip to content</a>
            <div class="header-nav">
                <div class="container d-md-flex align-items-center justify-content-between">
                    <div class="logo-search d-flex align-items-center">
                        <!-- Menu mobile -->
                        <button class="navbar-toggler hamburger hamburger--slider is-active d-block" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                        <!-- Menu desktop -->
                        <div class="logo">
                            <!-- Your site title as branding in the menu -->
                            <h1>
                                <a class="logo-text" rel="home" href="/">
                                    <span class="logo-word-1">{@var:site_name}</span>
                                    <span class="logo-word-2"></span>
                                </a>
                            </h1>
                            <!-- end custom logo -->
                        </div>
                        <div class="d-none d-md-block header-search">
                            <form id="Search_pc" method="get" action="/search.php">
                                <input class="input-group-field" value="" name="content" type="text" />
                                <button class="fa-input" type="submit" id="searchsubmit" value="&#xf002;">
                                    <i class="fa fa-search"></i>
                                </button>
                            </form>
                        </div>
                        <div class="d-block d-md-none membership">
                            <div class="d-inline-block d-md-none user-mobile">
                                <a href="/" target="_blank" rel="nofollow noopener"><i class="fa fa-home"></i></a>
                            </div>
                        </div>
                    </div>
                    <h2 class="d-none d-xl-block header-title">最新网址 </h2>
                </div>
            </div>
            <div class="d-block d-md-none header-search">
                <form  method="get" action="/search.php">
                    <input class="input-group-field" name="content" type="text" />
                    <button class="fa-input" type="submit" id="searchsubmit" value="&#xf002;">
                        <i class="fa fa-search"></i>
                    </button>
                </form>
            </div>
            <style>
                @media (max-width: 767.98px) {
                    .navbar-dark .navbar-collapse ul.yidongduanfenlei {
                        padding-top: 35px;
                        height: auto;
                    }

                    ul.yidongduanfenlei li {
                        width: 33%;
                        float: left;
                    }
                }

                .navbtn {
                    background-color: #007bff;
                    color: #fff;
                    border-color: #007bff;
                }

                .navbtn a:hover,
                .navbtnon a {
                    background-color: #000 !important;
                    color: #fff !important;
                    border-color: #000 !important;
                }
            </style>
            <nav class="navbar navbar-expand-md navbar-dark">
                <div class="container">
                    <div id="navbarNavDropdown" class="collapse navbar-collapse show">
                        <ul id="menu-main-menu" class="navbar-nav ml-auto   yidongduanfenlei">
                            <li id="menu-item-464" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-464 nav-item ">
                                <a title="Home" href="/" class="btn btn-primary navbtn">网站首页</a>
                            </li>

                            {nav type:video no:v2 count:8}
                                <li id="menu-item-464" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-464 nav-item ">
                                    <a href="{_class_link}" class="btn btn-primary navbtn">{_class_name}</a>
                                </li>
                            {/nav}
                            {nav type:bt no:1 count:2 name:国产磁力,日本磁力}
                              <li id="menu-item-464" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-464 nav-item ">
                                    <a href="{_class_link}" class="btn btn-primary navbtn">{_class_name}</a>
                                </li>
                            {/nav}

                        </ul>
                    </div>
                </div>
            </nav>
            <div class="clear"></div>
        </div>
        <div id="content">
            <div class="container home">
                <style>
                    .block_app {
                        width: 100%;
                        margin: 5px auto;
                        display: flex;
                        flex-wrap: wrap;
                        justify-content: center
                    }

                    .block_app img {
                        border-radius: 30%;
                        width: 50px;
                        height: 50px;
                        object-fit: cover;
                        border: 2px solid gray
                    }

                    .block_app_item {
                        display: block;
                        text-decoration: none;
                    }

                    .block_app_item_title {
                        text-align: center;
                        font-size: 14px;
                        font-weight: 600;
                        color: #E33A65
                    }

                    .block_app_item_image {
                        margin: 13px
                    }

                    @media only screen and (max-width:768px) {
                        .block_app img {
                            width: 50px;
                            height: 50px
                        }

                        .block_app_item_title {
                            font-size: 12px
                        }

                        .block_app_item_image {
                            margin: 5px
                        }
                    }
                </style>
                <style>
                    /*.block_app{width:960px;margin:10px auto;}*/
                    @media (max-width:960px) {
                        .block_app {
                            width: 96%
                        }
                    }
                </style>
<!--                 <div class="block_app">
                    <span class="">
                        <a class="block_app_item ck_x" data-id="3221" href="https://www.jzydh.com" target="_blank" rel="nofollow">
                            <img class="block_app_item_image  lazy" data-src="/upload/173614111.jpg">
                            <div class="block_app_item_title">AV集中营</div>
                        </a>
                    </span>
                    <span class="">
                        <a class="block_app_item ck_x" data-id="4071" href="https://礎觸.xx1yjy.xyz/links/" target="_blank" rel="nofollow">
                            <img class="block_app_item_image  lazy" data-src="/upload/174912471.ico">
                            <div class="block_app_item_title">XX研究院</div>
                        </a>
                    </span>
                </div> -->
                <style>
                    .ljbtn {
                        font-size: 16px !important;
                        padding: 8px 15px !important;
                    }

                    @media (max-width: 768px) {
                        .ljbtn {
                            font-size: 14px !important;
                            padding: 2px 6px !important;
                        }
                    }
                </style>
                <ul class="navbar-nav ml-auto youqinglj">
                    <li class=" link-menu">
                        <a class="btn btn-black ljbtn" style="background-color: #007bff!important;color: #fff;border-color: #007bff!important;">友情链接：</a>
                    </li>
                    {link area:link_yqlj}
                    <li class="link-menu">
                        <a href="{_url}" target="_blank" rel="nofollow" class="btn ljbtn" style="color:;">{base64}{_text}{/base64}</a>
                    </li>
                    {/link}
                </ul>
                <ul class="navbar-nav ml-auto youqinglj">
                    <li class=" link-menu">
                        <a class="btn btn-black ljbtn" style="    background-color: #007bff!important;color: #fff;border-color: #007bff!important;">热搜种子：</a>
                    </li>


                    {splite var:hot_torrent_tags}
                    <li class="link-menu">
                        <a href="/search.php?content={_var}&type=2" class="btn ljbtn" style="color: #007bff;">{base64}{_var}{/base64}</a>
                    </li>
                    {/splite}
                </ul>