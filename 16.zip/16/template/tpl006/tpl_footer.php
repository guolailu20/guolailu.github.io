                <section class="section pd-0" style="padding-top: 0px;">
                    <div class="wrap">
                        <div class="popular-searches">
                            <div class="title">
                                <h2 style="font-size: 18px;">🔍热门视频</h2>
                            </div>
                            <div class="block-searches flex xiuzheng" id="suijisousuoci">
                            {splite var:tags_hot_video}
                                <a href="/search.php?content={_var}&type=1">{_var}</a>
                            {/splite}
                            </div>
                        </div>
                    </div>
                    <div class="wrap">
                        <div class="popular-searches">
                            <div class="title">
                                <h2 style="font-size: 18px;">🤝友情链接</h2>
                            </div>
                            <div class="block-searches flex xiuzheng">
                                {link area:link_yqlj}
                                <a target="_blank" rel="nofollow noopener" href="{_url}" style="color:#FF0000;">{base64}{_text}{/base64}</a>
                                {/link}
                            </div>
                        </div>
                    </div>
                </section>
        </main>
        
        <div class="footer">
            <div class="wrap">
                <div class="block">
                    <a class="logo" href="/"><img src="/template/{@var:cms_config_tpl_dir}/picture/logo.png" width="198" height="38" /></a>
                    <div class="nav flex">
                        {base64}{@var:footer_contact}{/base64}
                    </div>
                    <div class="copyright d">
                        <p>{base64}{@var:footer_statement}{/base64}</p>
                    </div>
                </div>
            </div>
        </div>



{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}