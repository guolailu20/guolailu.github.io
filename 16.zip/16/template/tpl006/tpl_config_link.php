<?php exit();?>
link_bztj === 本站推荐 === 位于页面顶部
link_yqlj === 友情链接 === 位于页面底部