<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{@page_title}</title>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js" type="application/javascript"></script>
    <link href="/template/{@var:cms_config_tpl_dir}/css/style.css" rel="stylesheet">
    {@common_head}
</head>
<style>
    /*header {padding: 150px 0 0;}*/
    .bisex {
        top: auto;
    }

    body {
        background: #F8E6E6;
        color: #ff2668;
    }

    header {
        background: #F8E6E6;
    }

    .bisex {
        background: #df8888;
        box-shadow: 0px 2px 11px 0px rgba(163, 163, 163, 0.3);
    }

    @media (min-width: 960px) {
        header .iterate {
            float: right;
        }
    }

    header .iterate .through .begins {
        background: #ffffff;
    }

    header .iterate .through .bondman {
        color: #df8888;
    }

    header .breasts {
        background: #ff2668;
        color: #ffffff;
    }

    .expect h1,
    .expect h2,
    .expect h3 {
        color: #E33A65;
    }

    @media (min-width: 960px) {
        .fs18 {
            font-size: 18px;
            line-height: 30px;
        }
    }

    @media (max-width: 960px) {
        .bisex {
            background: #ff2668;
        }

        .ploughs ul li.thigh a,
        .ploughs ul li a:hover {
            color: #000000;
        }
    }

    .ftitle {
        font-size: 20px;
        font-weight: normal;
        margin: 3px auto 3px 0;
        color: #E33A65;
    }

    .enslave .small .depraved .shoving {
        background: #df8888;
    }

    .enslave .small .depraved .seem .chicks {
        background: #df8888;
    }

    .chode a,
    .chode span {
        background-color: #df8888;
    }
</style>

<body>


    {@include file:header}

    <section class="torture">
        <div class="exclusive">
            <div class="expect">
                <h1>{@name}</h1>
            </div>
            <article class="muscular">
                                    <script src="https://cdn.jsdelivr.net/hls.js/latest/hls.min.js"></script>
                                    <video class="player-box" src="{@m3u8}" id="video"  controls autoplay style="width:100%;max-height: 600px;"></video>
                                    <script>
                                        if (Hls.isSupported()) {
                                            var video = document.getElementById('video'); // 获取 video 标签
                                            var hls = new Hls(); // 实例化 Hls 对象
                                            hls.loadSource('{@m3u8}'); // 传入路径
                                            hls.attachMedia(video);
                                            hls.on(Hls.Events.MANIFEST_PARSED, function () {
                                                video.play(); // 调用播放 API
                                            });
                                        }
                                    </script>

            </article>

        </div>
    </section>
    <section class="throughout">
        <div class="exclusive">
            <div class="expect">
                <h3>相关视频</h3>
            </div>
            <div class="enslave">


                {list type:video mode:rand total:10 title_len:24}
                <div class="small likes">
                    <a class="depraved" href="{_url}">
                        <div class="seem"><img class="lazy" src="/template/{@var:cms_config_tpl_dir}/picture/lazy.svg" original="{_pic}" alt=""></div>
                        <div class="shoving">{_title}</div>
                    </a>
                </div>
                {/list}

            </div>
        </div>
    </section>
    {@include file:footer}
</body>

</html>