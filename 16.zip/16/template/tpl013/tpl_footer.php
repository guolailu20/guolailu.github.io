

    
    <style>
        .foothz {
            width: 80%;
            overflow: hidden;
            display: block;
            /*box-shadow: 0 1px 1px 0 rgba(0,0,0,.05);*/
            margin: 0px auto;
        }

        .foothzlist a {
            padding: 5px 10px;
            margin: 1px;
            background-color: #fff;
            color: #000;
            border-radius: 5px;
            display: inline-block;
            text-decoration: none;
            margin-bottom: 3px;
            text-align: center;
        }

        .foothzlist a:hover {
            background: #f80;
        }

        @media screen and (max-width: 767px) {
            .foothz {
                width: 95%;
            }

            .foothzlist a {
                width: 24.4%;
                padding: 5px 0px;
                float: left;
                font-size: 13px;
                margin: 1px;
            }
        }
    </style>
    <div class="foothz">
        <div class="">
            <h1 style="font-size: 18px;border-bottom: 3px solid #000;padding: 3px 10px;color: #000;line-height: 28px;text-align: center;">友情链接</h1>
        </div>
        <div class="foothzlist">
{link area:link_yqlj}
            <a data-id="1613" href="{_url}" target="_blank" class="dh" rel="nofollow">{base64}{_text}{/base64}</a></li>
{/link}
        </div>
    </div>
    <div class="temo">TG:@</div>
    <p style="text-align: center;font-size: 1.2rem;">联络邮箱：</p>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js"></script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.lazyload.js"></script>
<script type="text/javascript">
$("img.lazy").lazyload({
effect : "fadeIn"
});
</script>


{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}