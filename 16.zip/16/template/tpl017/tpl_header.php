{ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;margin: 1px 0px;" class="{_class}"></a>
</div>
{/ad}

    <header>
        <h1>
            <div class="wrap">
                <a href="/" class="header-title"><img src="/template/{@var:cms_config_tpl_dir}/picture/wei1.png"  /></a>

                <form method="get" action="/search.php"  class="soso" method="get">
                    <input class="keywd" name="content" placeholder="请输入关键词搜索" id="searchInput" />
                    <button type="submit" >
                        <svg t="1655274004524" class="icon" viewbox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3068">
                            <path d="M1008.160651 931.256445l-177.567435-177.567436A464.412483 464.412483 0 1 0 639.131615 897.076798a57.521845 57.521845 0 1 0-43.071914-106.707191 350.758209 350.758209 0 1 1 118.100408-78.988332 10.976391 10.976391 0 0 0-0.83365 1.042063 6.530258 6.530258 0 0 1-0.83365 0.625237 54.465129 54.465129 0 0 0-5.696608 69.887653 58.286024 58.286024 0 0 0 7.850203 9.864857c1.042062 0.972592 2.223066 1.736771 3.3346 2.639892l212.719674 212.719674a54.604071 54.604071 0 0 0 76.904207 0 54.604071 54.604071 0 0 0 0.555766-76.904206z" p-id="3069"></path>
                        </svg></button>
                </form>

            </div>
        </h1>
    </header>
    <div class="nav" style="width: 99%;">
        <a class="on" href="/">网站首页</a>
{nav type:video no:v2 count:7} 
<a href="{_class_link}" >{_class_name}</a>
{/nav}
{nav type:bt no:1 count:2 name:国产磁力,日本磁力} 
<a href="{_class_link}" >{_class_name}</a>
{/nav}
    </div>



    <div style="padding: 0px;">
        <div class="index-tabs">
{link area:link_dblj}
<a target="_blank" href="{_url}" style="color:#fff !important;background: rgb(161, 80, 80) !important;" class="btn"  rel="nofollow">{base64}{_text}{/base64}</a>
{/link}
        </div>

    </div>


<!--     <div class="group-box index-text bg-card" style="padding: 0px;">
        <div class="index-tabs bg-card">
            <a href="https://..com" style="color:#fff !important;background: #3965aa !important;" class="btn"  rel="nofollow">传送门</a>
            <a href="https://禾/d华华" style="color:#fff !important;background: #3965aa !important;" class="btn"  rel="nofollow">隐秘部落</a>
        </div>

    </div> -->

    <br />

    <div class="tags-box container">
        <div class="tags">
            <span class="tags-1 has-text-centered">
                <div class="label2" id="">
{splite var:search_tags_torrent}
<a href="/search.php?content=b64{_var_b64}&type=2">{base64}{_var}{/base64}</a>
{/splite}
                </div>
            </span>
        </div>
    </div>


<!--     <div class="row">

        <div class="photo-two"><a href="/links2/151.html" ><img class="img lazy" data-original="/template/{@var:cms_config_tpl_dir}/picture/65b11b519d812fdcbb73fac0.gif" src="https://www.xn--1qwynp09f.net/images/65b11b519d812fdcbb73fac0.gif"><br><span class="photo-name" style="color:#448bff">澳门赌场</span></a></div>
        <div class="photo-two"><a href="/links2/116.html" ><img class="img lazy" data-original="/template/{@var:cms_config_tpl_dir}/picture/meiai111.gif" src="https://cdn.baiducdn2img.com/app/img/meiai111.gif"><br><span class="photo-name" style="color:#448bff">妻友社区</span></a></div>


    </div> -->


