<?php exit();?><!DOCTYPE html>
<html>
<head>
    <title>{@page_title}</title>
    <meta http-equiv="keywords" content="{@site_keyword}">
    <meta http-equiv="description" content="{@site_desc}">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/common.css" type="text/css">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/hmlcss.css" type="text/css">
    <link rel="stylesheet" href="/template/{@var:cms_config_tpl_dir}/css/app.css" type="text/css">
    <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js"></script>
    <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/jquery.lazyload.min.js"></script>
    <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/common.js"></script>
    {@common_head}
</head>

<body>
    {@include file:header}
    <div class="container">
        <div class="content">
            <div class="mhlleset clearfix">
                <div class="mhlleset-main">
                    <div class="mhlleset-heading clearfix" style="overflow: hidden;">
                        <h3 class="mhlleset-title"><a href="{@class_link type:video index:4}">{@class_name type:video index:4}</a></h3>
                    </div>
                    <ul class="thumbnail-group clearfix">
                    {list type:video index:4 total:8 title_len:24}
                        <li>
                            <a class="thumbnail" href="{_url}">
                                <img class="loadi" data-original="{_pic}" src="/template/{@var:cms_config_tpl_dir}/images/loading.svg">
                            </a>
                            <div class="video-info">
                                <h5><a href="{_url}">{_title}</a></h5>
                                </p>
                            </div>
                        </li>
                    {/list}
                    </ul>
                </div>
            </div>


            <div class="mhlleset clearfix">
                <div class="mhlleset-main">
                    <div class="mhlleset-heading clearfix" style="overflow: hidden;">
                        <h3 class="mhlleset-title"><a href="{@class_link type:video index:1}">{@class_name type:video index:1}</a></h3>
                    </div>
                    <ul class="thumbnail-group clearfix">
                    {list type:video index:1 total:8 title_len:24}
                        <li>
                            <a class="thumbnail" href="{_url}">
                                <img class="loadi" data-original="{_pic}" src="/template/{@var:cms_config_tpl_dir}/images/loading.svg">
                            </a>
                            <div class="video-info">
                                <h5><a href="{_url}">{_title}</a></h5>
                                </p>
                            </div>
                        </li>
                    {/list}
                    </ul>
                </div>
            </div>


            <div class="mhlleset clearfix">
                <div class="mhlleset-main">
                    <div class="mhlleset-heading clearfix" style="overflow: hidden;">
                        <h3 class="mhlleset-title"><a href="{@class_link type:video index:2}">{@class_name type:video index:2}</a></h3>
                    </div>
                    <ul class="thumbnail-group clearfix">
                    {list type:video index:2 total:8 title_len:24}
                        <li>
                            <a class="thumbnail" href="{_url}">
                                <img class="loadi" data-original="{_pic}" src="/template/{@var:cms_config_tpl_dir}/images/loading.svg">
                            </a>
                            <div class="video-info">
                                <h5><a href="{_url}">{_title}</a></h5>
                                </p>
                            </div>
                        </li>
                    {/list}
                    </ul>
                </div>
            </div>




            <div class="mhlleset clearfix">
                <div class="mhlleset-main">
                    <div class="mhlleset-heading clearfix" style="overflow: hidden;">
                        <h3 class="mhlleset-title"><a href="{@class_link type:video index:3}">{@class_name type:video index:3}</a></h3>
                    </div>
                    <ul class="thumbnail-group clearfix">
                    {list type:video index:3 total:8 title_len:24}
                        <li>
                            <a class="thumbnail" href="{_url}">
                                <img class="loadi" data-original="{_pic}" src="/template/{@var:cms_config_tpl_dir}/images/loading.svg">
                            </a>
                            <div class="video-info">
                                <h5><a href="{_url}">{_title}</a></h5>
                                </p>
                            </div>
                        </li>
                    {/list}
                    </ul>
                </div>
            </div>


            <div class="mhlleset clearfix">
                <div class="mhlleset-main">
                    <div class="mhlleset-heading clearfix" style="overflow: hidden;">
                        <h3 class="mhlleset-title"><a href="{@class_link type:bt index:1}">{@class_name type:bt index:1}</a></h3>
                    </div>
                    <ul class="thumbnail-group clearfix">
                    {list type:bt index:1 total:8 title_len:24}
                        <li>
                            <a class="thumbnail" href="{_url}">
                                <img class="loadi" data-original="{_pic}" src="/template/{@var:cms_config_tpl_dir}/images/loading.svg">
                            </a>
                            <div class="video-info">
                                <h5><a href="{_url}">{_title}</a></h5>
                                </p>
                            </div>
                        </li>
                    {/list}
                    </ul>
                </div>
            </div>

            <div class="mhlleset clearfix">
                <div class="mhlleset-main">
                    <div class="mhlleset-heading clearfix" style="overflow: hidden;">
                        <h3 class="mhlleset-title"><a href="{@class_link type:bt index:2}">{@class_name type:bt index:2}</a></h3>
                    </div>
                    <ul class="thumbnail-group clearfix">
                    {list type:bt index:2 total:8 title_len:24}
                        <li>
                            <a class="thumbnail" href="{_url}">
                                <img class="loadi" data-original="{_pic}" src="/template/{@var:cms_config_tpl_dir}/images/loading.svg">
                            </a>
                            <div class="video-info">
                                <h5><a href="{_url}">{_title}</a></h5>
                                </p>
                            </div>
                        </li>
                    {/list}
                    </ul>
                </div>
            </div>
        </div>
    </div>
    {@include file:footer}
</body>
</html>