<?php exit();?>
benzhantuijian === 本站推荐 === 位于栏目导航下
hezuohuoban === 合作伙伴 === 位于栏目导航下方
youqinglianjie === 友情链接 === 位于页面底部