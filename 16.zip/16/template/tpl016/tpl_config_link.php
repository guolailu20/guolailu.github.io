<?php exit();?>
link_yqlj === 友情链接 === 页面上方