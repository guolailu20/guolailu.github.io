

            <style>
                .sotags_f span a {
                    color: #fff;
                    font-size: 12px;
                    font-weight: 500;
                    letter-spacing: 0.3px;
                    border-radius: 15px;
                    padding: 8px 10px;
                    background-color: #000000;
                    margin: 2px 0 2px 3px;
                }
            </style>
<!--             <div class="sotags  sotags_f">
                <span class="tagtitle">Tags:</span>
                <span><a href="/index.php?m=vod-search-wd-%E5%93%AD.htm">哭</a></span>
                <span><a href="/index.php?m=vod-search-wd-%E7%BE%8E%E7%A9%B4.htm">美穴</a></span>
            </div>
            <style>
                .grid-item {
                    background: #CF82B3;
                }
            </style>
            <div style="width: 100%;margin-left: auto; margin-right: auto">
                <h3 style="margin:0px auto 0px 0;color:#212121;font-size:2.4rem;font-weight:500;text-align:center;">友情链接</h3>
                <div class="grid-container">
                    <div class="grid-item d" style="background: #;">
                        <a href="https://www.avjishi2023.de/三思而后行/" data-id="7942"  style="color:;">AV集市</a>
                    </div>
                    <div class="grid-item d" style="background: #;">
                        <a href="https://www.nbdh17.buzz/" data-id="3"  style="color:;">牛逼导航</a>
                    </div>
                </div>
            </div> -->
        </div>
        <div>
            <div class="content">
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="footer-wrap">
            <div class="copyright"><a href="/">{@site_name}</a><br />All rights reserved</div>
            <div class="txt">联络邮箱 : </div>
        </div>

    </div>
    <script type="text/javascript">
        $(".navigation button").click(function() {
            $(this).parents(".navigation").toggleClass("open")
        })
    </script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.lazyload.min.js" type="application/javascript"></script>
    <script type="text/javascript">
        $(function() {
            $("img.lazy-load").lazyload();
        });
    </script>
    <div style="display:none">
    </div>

{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}