


<!-- 
            <div class="container sokeytags block-video" style="background: #fff;padding: 10px 0px 10px 0px;">
                <ul style="padding: 0;">
                    <li class=""><a href="/?mod=videos&wd=%E5%85%AC%E4%B8%BB">公主</a></li>
                    <li class=""><a href="/?mod=videos&wd=%E5%B7%A8%E4%B9%B3%E7%86%9F%E5%A5%B3">巨乳熟女</a></li>
                </ul>
            </div> -->
<!--             <div class="zoom-anim-dialog mfp-hide popup" id="popup-categories"></div>
            <div class="zoom-anim-dialog  popup" id="popup-sponsors">
                <strong class="popup-title ">友情链接</strong>
                <style>
                    .youiqnglianjie ul li {
                        display: inline-block;
                        font-size: 14px;
                    }
                </style>
                <div class="wrap2    youiqnglianjie">
                    <ul class="popup-categories-list">
                        <li class=""><a data-id="7934" class="item" href="htcc"  rel="sponsored noopener">A级文化</a></li>
                        <li class=""><a data-id="7933" class="item" href="hcc"  rel="sponsored noopener">两性百科</a></li>
                    </ul>
                </div>
            </div> -->
            <!-- 
<div class="zoom-anim-dialog mfp-hide popup" id="popup-models">
</div>
-->
        </div>
        <div class="footer" style="margin-top: 0;">
            <div class="footer-wrap">
                <!-- 
<ul class="nav">
<li><a href="/">Home</a></li>
</ul>
-->
                <div class="copyright d">
                    All rights reserved. Powered by SeyouCMS</div>
                <div class="txt d">we are always on the lookout for fresh content, and we are better than your lazy girlfriend!</div>
            </div>
            <a href="#header" class="arrow-up" onclick="$('html,body').animate({scrollTop:0},'slow');return false;">up</a>
        </div>
    </div>

    <script type='text/javascript' src='/template/{@var:cms_config_tpl_dir}/js/jquery.lazyload.js'></script>
    <script type="text/javascript">
        $(function() {
            $("img.lazy").lazyload();
        });
    </script>
    <script src="/template/{@var:cms_config_tpl_dir}/js/js.js"></script>





{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}