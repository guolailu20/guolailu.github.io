    <table border="0" align="center" cellpadding="0" cellspacing="0" id="daohang0">
        <div style="max-width: 1200px; margin: 0px auto;">
    {ad area:hengfu1}
<div style="width: 100%;margin: 1px 0px;" class="{_class}">
    <a href="{_url}" target="_blank" rel="nofollow">
        <img src="{_image}" style="width: 100%;margin: 1px 0px;" class="{_class}"></a>
</div>
{/ad}
</div>
        <tr>
            <td width="50">
                <h2><a href="/"><img src="/template/{@var:cms_config_tpl_dir}/picture/logo.png" border="0" /></a></h2>
            </td>
            <td width="150">
                <h2><a href="/">{@site_name}</a></h2>
            </td>
            <form action="/s/?s=s" method="get" class="sidebar-search full-width"><input name="s" type="hidden" value="s" />
                <td>
                    <div class="wrap">
                        <div class="search"><input name="guanjian" type="text" class="searchTerm" id="guanjian" placeholder="你想找什么?"><button type="submit" class="searchButton">GO</button></div>
                    </div>
                </td>
            </form>
        </tr>
    </table>
    <div class="shangsou">
        <form action="/s/?s=s" method="get" class="sidebar-search full-width"><input name="s" type="hidden" value="s" />
            <div class="search"><input name="guanjian" type="text" class="searchTerm" id="guanjian" placeholder="你想找什么?"><button type="submit" class="searchButton">GO</button></div>
        </form>
    </div>
    <table border="0" align="center" cellpadding="0" cellspacing="0" id="daohang">
        <tr>
            <td align="center">
                <a href='/'>网站首页</a>
{nav type:video no:v2 count:6} 
                <a href='{_class_link}'>{_class_name}</a>
{/nav}
{nav type:bt no:1 count:2 name:国产磁力,日本磁力} 
                <a href='{_class_link}'>{_class_name}</a>
{/nav}
            </td>
        </tr>
    </table>


    <h1 style="font-size: 16px;color: #000000;line-height: 16px;text-align: center;">推荐导航</h1>
    <hr style="color: #000000;">
    </hr>
    <div class="zztj" align="center">        
{link area:link_tjdh}
<a href='{_url}' >{base64}{_text}{/base64}</a>
{/link}
    </div>