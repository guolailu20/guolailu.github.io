
<!-- 
    <table border="0" align="center" cellpadding="0" cellspacing="0" id="daohang0">
        <tr>
            <td height="50">友情链接：<a href='hom=3f7hqa' >小丝丝</a>
                <a href='httpyJj' >文尼导航</a>
            </td>
        </tr>
    </table> -->
    <p>
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" id="daohang7">
        <tr>
            <td height="130" align="center" bgcolor="#929CC2">警告︰本網站只這合十八歲或以上人士觀看。內容可能令人反感；不可將本網站的內容派發、傳閱、出售、出租、交給或借予年齡未滿18歲的人士或將本網站內容向該人士出示、播放或放映。<br />站点申明：我们立足于美利坚合众国，受北美法律保护,未满18岁或被误导来到这里，请立即离开！</td>
        </tr>
    </table>
    <div id="wu">
        <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.min.js"></script>
        <script src="/template/{@var:cms_config_tpl_dir}/js/jquery.lazyload.min.js"></script>
        <script type="text/javascript">
            $(".lazy").lazyload({
                effect: "fadeIn",
                threshold: 200,
                failurelimit: 10,
                skip_invisible: false
            })
        </script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/news.js"></script>
        <script type="text/javascript" src="/template/{@var:cms_config_tpl_dir}/js/t.js"></script>
    </div>


{ad area:dipiao}
{/ad}

<!--{@debug}-->
<!--{@source_debug}-->
{@site_tongji}

{ad area:js}
{/ad}