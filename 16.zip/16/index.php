<?php
unset($_GET);
unset($_POST);
unset($_COOKIE);

define('INC', true);
include dirname(__FILE__)."/common.php";

$tpl_html = file_get_contents_x("template/$cms_config_tpl_dir/tpl_index.php");

if(!empty($cms_config_site_title)){
    $page_title = $cms_config_site_title;
}else{
    $page_title = $cms_config_site_name;
}

include $base_dir . "/module_parse_tpl.php";

echo $tpl_html;

if(!empty($cache_file_path)){
    cache_end($cache_file_path);
}